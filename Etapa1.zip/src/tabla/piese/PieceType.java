package tabla.piese;

public enum PieceType {
    PION
}

package tabla;

public enum PlayerColor {
    WHITE, BLACK
}

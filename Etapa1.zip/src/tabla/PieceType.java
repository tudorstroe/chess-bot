package tabla;

public enum PieceType {
    PION
}

package tabla;

public enum PieceType {
    PION,
    CAL,
    NEBUN,
    TURA,
    REGE,
    REGINA

}

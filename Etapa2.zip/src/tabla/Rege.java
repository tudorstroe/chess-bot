package tabla;

public class Rege extends Piece{
    public Rege(Patratel patratel, PlayerColor color) {
        super(patratel, color);
        type = PieceType.REGE;
    }
}

package tabla;

public class Nebun extends Piece{
    public Nebun(Patratel patratel, PlayerColor color) {
        super(patratel, color);
        type = PieceType.NEBUN;
    }
}
